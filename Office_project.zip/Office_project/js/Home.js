let iconCart = document.querySelector('.icon-cart')
let body = document.querySelector('body');
let closeCart = document.querySelector('.close')
let listProductHTML = document.querySelector('.listProduct')


let listProducts = []

iconCart.addEventListener('click',()=>{
      body.classList.toggle('ShowCart')
})

closeCart.addEventListener('click',()=>{
    body.classList.toggle('ShowCart')
})

const addDataToHTML=()=>{ 
     listProductHTML.innerHTML = ' '
     if(listProducts.length>0) {
         listProducts.forEach(product=>{ 
              let newProduct = document.createElement('div');
              newProduct.classList.add('item');
              newProduct.dataset.id = product.id;
              newProduct.innerHTML = `
                <img src="${product.image}" alt="Product Image"> 
                <h2>${product.image}</h2> 
                <div class="price">${product.price}</div>
                <button class="addCart">Add To Cart</button>
              `;
              listProductHTML.appendChild(newProduct);
         })
     }
}


listProductHTML.addEventListener('click',(e)=>{
      let positionClick = e.target;
      if(positionClick.classList.contains('addCart')) {
          let product_id = positionClick.parentElement.dataset.id
          alert(product_id);
      }
})

const initApp = () => { 
    fetch('../product.json')
        .then(res => res.json())  
        .then(data => {
            listProducts = data;
            console.log(data);
            addDataToHTML();
        })
        .catch(error => console.error('Error fetching products:', error));
};


initApp();












