const loginForm = document.getElementById("login-form");
const loginEmail = document.getElementById("login_email");
const loginPassword = document.getElementById("login_password");

loginForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const registeredEmail = localStorage.getItem("registeredEmail");
  const registeredPassword = localStorage.getItem("registeredPassword");

  if (!registeredEmail || !registeredPassword) {
    showPopup("No registered account found. Please sign up first.", "error");
    setTimeout(() => {
      window.location.href = "../index.html"; // Redirect to signup page
    }, 2000);
    return;
  }

  if (loginEmail.value.trim() === registeredEmail && loginPassword.value.trim() === registeredPassword) {
    showPopup("Login successful! Redirecting...", "success");
    setTimeout(() => {
      window.location.href = "./home.html"; // Redirect after success
    }, 2000);
  } else {
    showPopup("Invalid email or password. Please try again.", "error");
  }
});

// Function to show pop-up messages
function showPopup(message, type) {
  const popup = document.createElement("div");
  popup.textContent = message;
  popup.style.position = "fixed";
  popup.style.top = "20px";
  popup.style.left = "50%";
  popup.style.transform = "translateX(-50%)";
  popup.style.backgroundColor = type === "success" ? "green" : "red";
  popup.style.color = "white";
  popup.style.padding = "10px 20px";
  popup.style.borderRadius = "5px";
  popup.style.zIndex = "1000";
  document.body.appendChild(popup);

  setTimeout(() => {
    popup.remove();
  }, 2000);
}
