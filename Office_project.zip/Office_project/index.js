const form = document.getElementById("form");
const first_input = document.getElementById("first_input");
const email_input = document.getElementById("email_input");
const password_input = document.getElementById("password_input");
const repassword_input = document.getElementById("repassword_input");

form.addEventListener("submit", (e) => {
  e.preventDefault();

  let errors = getSignupFormErrors(
    first_input.value.trim(),
    email_input.value.trim(),
    password_input.value.trim(),
    repassword_input.value.trim()
  );

  if (errors.length > 0) {
    alert(errors.join("\n")); // Show all errors in an alert
  } else {
    // ✅ Save user data in localStorage
    localStorage.setItem("registeredName", first_input.value.trim());
    localStorage.setItem("registeredEmail", email_input.value.trim());
    localStorage.setItem("registeredPassword", password_input.value.trim());

    alert("Registration successful! Redirecting to login...");
    window.location.href = "./views/Login.html"; // Redirect to login page
  }
});

// Validate form fields
function getSignupFormErrors(firstname, email, password, repassword) {
  let errors = [];

  if (!firstname) {
    errors.push("First name is required");
  }

  if (!email) {
    errors.push("Email is required");
  } else if (!isValidEmail(email)) {
    errors.push("Invalid email format");
  }

  if (!password) {
    errors.push("Password is required");
  } else if (password.length < 6) {
    errors.push("Password must be at least 6 characters long");
  }

  if (!repassword) {
    errors.push("Confirm password is required");
  } else if (repassword !== password) {
    errors.push("Passwords do not match");
  }

  return errors;
}

// Function to validate email format
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}
